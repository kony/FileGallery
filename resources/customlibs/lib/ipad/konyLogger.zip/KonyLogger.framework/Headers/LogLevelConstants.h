//
//  LogLevelConstants.h
//  Logger
//
//  Created by Harshini Bonam on 26/08/16.
//  Copyright © 2016 kony. All rights reserved.
//


/**
 * Log levels for the Logger
 */
#import <Foundation/Foundation.h>

typedef NS_OPTIONS(NSUInteger, LogLevel) {
    /**
     * Logs Nothing
     */
    LogLevelNone        = 63,
    
    /**
     * Logs Traces
     */
    LogLevelTrace       = 1,
    
    /**
     * Logs messages relevant to debugging of code (by developers)
     */
    LogLevelDebug       = 2,
    
    /**
     * Logs Info
     */
    LogLevelInfo        = 4,
    
    /**
     * Logs Warnings 
     */
    LogLevelWarning     = 8,
    
    /**
     * Logs errors
     */
    LogLevelError       = 16,
    
    /**
     * Logs Fatal Errors
     */
    LogLevelFatal       = 32,
    
    /**
     * Logs every level of log statements
     */
    LogLevelAll         = 0
};

@interface LogLevelConstants :NSObject

@end
